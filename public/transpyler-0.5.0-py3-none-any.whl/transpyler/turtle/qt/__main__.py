from .runners import start_client


if __name__ == '__main__':
    start_client()
