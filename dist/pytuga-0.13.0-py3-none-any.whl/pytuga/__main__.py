from transpyler import get_transpyler


def main():
    """
    Pytuga main entry point.
    """
    get_transpyler().start_main()


if __name__ == '__main__':
    main()
